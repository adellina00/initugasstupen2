package com.example.myapplication

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Hero(
    val imgHero: Int,
    val nameHero: String,
    val descHero: String
) : Parcelable
